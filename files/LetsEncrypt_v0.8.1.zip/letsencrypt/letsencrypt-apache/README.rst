This package is a simple shim for backwards compatibility around
``certbot-apache``, the Apache plugin for ``certbot``.
