.. literalinclude:: cli-help.txt
