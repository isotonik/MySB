ChangeLog
=========

Please note:
the change log will only get updated after first release - for now please use the
`commit log <https://github.com/certbot/certbot/commits/master>`_.

To see the changes in a given release, inspect the github milestone for the
release.  For instance:

https://github.com/certbot/certbot/issues?utf8=%E2%9C%93&q=milestone%3A0.3.0
