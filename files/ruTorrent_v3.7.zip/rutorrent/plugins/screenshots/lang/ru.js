﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.exFFMPEG		= "Скриншоты";
 theUILang.exFrameWidth 	= "Ширина фрейма";
 theUILang.exFramesCount	= "Количество фреймов";
 theUILang.exStartOffset	= "Стартовое смещение";
 theUILang.exBetween		= "Время между фреймами";
 theUILang.exSave		= "Сохранить";
 theUILang.exSaveAll		= "Сохранить все";
 theUILang.exScreenshot 	= "Скриншот";
 theUILang.exPlayInterval	= "Интервал показа";
 theUILang.exImageFormat	= "Формат";

thePlugins.get("screenshots").langLoaded();