﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.exFFMPEG		= "Zrzuty Ekranu";
 theUILang.exFrameWidth 	= "Szerokość ramki";
 theUILang.exFramesCount	= "Ilość ramek";
 theUILang.exStartOffset	= "Przesunięcie względem początkowej ramki";
 theUILang.exBetween		= "Czas pomiędzy ramkami";
 theUILang.exSave		= "Zapisz";
 theUILang.exSaveAll		= "Zapisz wszystko";
 theUILang.exScreenshot 	= "Screenshot";
 theUILang.exPlayInterval	= "Interwał pokazu slajdów";
 theUILang.exImageFormat	= "Format obrazka";

thePlugins.get("screenshots").langLoaded();