﻿/*
 * PLUGIN SCREENSHOTS
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.exFFMPEG		= "Chụp màn hình";
 theUILang.exFrameWidth 	= "Độ rộng khung hình";
 theUILang.exFramesCount	= "Số khung hình";
 theUILang.exStartOffset	= "Khung hình bắt đầu từ";
 theUILang.exBetween		= "Thời gian giữa các khung hình";
 theUILang.exSave		= "Lưu lại";
 theUILang.exSaveAll		= "Lưu tất cả";
 theUILang.exScreenshot 	= "Chụp màn hình";
 theUILang.exPlayInterval	= "Thời gian trình diễn";
 theUILang.exImageFormat	= "Định dạng ảnh";

thePlugins.get("screenshots").langLoaded();