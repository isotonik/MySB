﻿/*
 * PLUGIN MEDIAINFO
 *
 * English language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";