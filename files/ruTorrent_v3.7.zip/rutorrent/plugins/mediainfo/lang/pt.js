﻿/*
 * PLUGIN MEDIAINFO
 *
 * Portuguese language file.
 *
 * Author: 
 */

 theUILang.mediainfo		= "Media Info";