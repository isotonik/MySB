﻿/*
 * PLUGIN RATIO
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.ratios		= "分享率设置";
 theUILang.ratio		= "分享率设置";
 theUILang.mnuRatio		= "设置分享率";
 theUILang.mnuRatioUnlimited	= "无限制";
 theUILang.ratioName		= "名称";
 theUILang.minRatio		= "最小";
 theUILang.maxRatio		= "最大";
 theUILang.ratioUpload		= "上传";
 theUILang.ratioAction		= "动作";
 theUILang.ratioStop		= "停止";
 theUILang.ratioStopAndRemove	= "停止 & 清除设置";
 theUILang.ratioErase		= "移除";
 theUILang.ratioEraseData	= "移除数据";
 theUILang.maxTime		= "时间";
 theUILang.ratioDefault 	= "默认分享率组";
 theUILang.setThrottleTo	= "将通道设为";

thePlugins.get("ratio").langLoaded();
