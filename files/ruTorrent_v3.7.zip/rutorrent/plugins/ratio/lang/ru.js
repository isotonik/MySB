﻿/*
 * PLUGIN RATIO
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.ratios		= "Группы ratio";
 theUILang.ratio		= "ГруппаRatio";
 theUILang.mnuRatio		= "Установить ratio";
 theUILang.mnuRatioUnlimited	= "Нет";
 theUILang.ratioName		= "Имя";
 theUILang.minRatio		= "Min";
 theUILang.maxRatio		= "Max";
 theUILang.ratioUpload		= "UL";
 theUILang.ratioAction		= "Действие";
 theUILang.ratioStop		= "Стоп";
 theUILang.ratioStopAndRemove	= "Стоп & очистить";
 theUILang.ratioErase		= "Удалить";
 theUILang.ratioEraseData	= "Удалить данные";
 theUILang.maxTime		= "Время";
 theUILang.ratioDefault 	= "Группа ratio по умолчанию";
 theUILang.setThrottleTo	= "Установить канал";

thePlugins.get("ratio").langLoaded();