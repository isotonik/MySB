﻿/*
 * PLUGIN TRAFFIC
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.traf 		= "流量";
 theUILang.perDay		= "每天";
 theUILang.perMonth		= "每月";
 theUILang.perYear		= "每年";
 theUILang.allTrackers		= "所有 Trackers";
 theUILang.ClearButton		= "清除";
 theUILang.ClearQuest		= "你确定要清除当前选择 Tracker 的统计信息吗?";
 theUILang.selectedTorrent	= "选择的 torrent(s)";
 theUILang.ratioDay		= "比/日";
 theUILang.ratioWeek		= "比/周";
 theUILang.ratioMonth		= "比/月";
