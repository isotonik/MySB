﻿/*
 * PLUGIN LookAt
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.lookAtDesc = "Дивитися на (Формат: name|url)";
 theUILang.lookAt = "Дивитися на";

thePlugins.get("lookat").langLoaded();
