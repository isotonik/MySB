﻿/*
 * PLUGIN LookAt
 *
 * French language file.
 *
 * Author: 
 */

 theUILang.lookAtDesc = "Chercher sur (Format: nom|url)";
 theUILang.lookAt = "Chercher sur";

thePlugins.get("lookat").langLoaded();