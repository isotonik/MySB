﻿/*
 * PLUGIN CREATE
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.mnu_create			= "Δημιουργία Torrent...";
 theUILang.CreateNewTorrent		= "Δημιουργία Νέου Torrent";
 theUILang.SelectSource 		= "Επιλογή πηγής";
 theUILang.TorrentProperties		= "Ιδιότητες Torrent";
 theUILang.PieceSize			= "Μέγεθος κομματιού";
 theUILang.Other			= "Άλλο";
 theUILang.StartSeeding 		= "Έναρξη αποστολής";
 theUILang.PrivateTorrent		= "Ιδιωτικό torrent";
 theUILang.torrentCreate		= "Δημιουργία...";
 theUILang.BadTorrentData		= "Πρέπει να συμπληρώσετε όλα τα απαιτούμενα πεδία!";
 theUILang.createExternalNotFound	= "Πρόσθετο Δημιουργία: Το πρόσθετο δεν θα λειτουργήσει. Ο χρήστης του διακομιστή Web δεν έχει πρόσβαση σε εξωτερικό πρόγραμμα";
 theUILang.incorrectDirectory		= "Εσφαλμένος φάκελος";
 theUILang.cantExecExternal		= "Δεν μπορεί να εκτελεστεί ένα εξωτερικό πρόγραμμα";
 theUILang.createConsole		= "Κονσόλα";
 theUILang.createErrors 		= "Σφάλματα";
 theUILang.torrentSave			= "Αποθήκευση";
 theUILang.torrentKill			= "Τερματισμός";
 theUILang.torrentKilled		= "Η λειτουργία τερματίστηκε.";
 theUILang.recentTrackers		= "Πρόσφατοι trackers"; 

thePlugins.get("create").langLoaded();