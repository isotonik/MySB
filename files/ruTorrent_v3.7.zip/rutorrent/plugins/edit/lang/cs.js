﻿/*
 * PLUGIN EDIT
 *
 * Czech language file.
 *
 * Author: 
 */

 theUILang.EditTrackers 		= "Edit Torrent...";
 theUILang.EditTorrentProperties	= "Torrent Properties";
 theUILang.errorAddTorrent		= "Error adding torrent file";
 theUILang.errorWriteTorrent		= "Error writing torrent file";
 theUILang.errorReadTorrent		= "Error reading torrent file";
 theUILang.cantFindTorrent		= "Source torrent file for this download not found."

thePlugins.get("edit").langLoaded();