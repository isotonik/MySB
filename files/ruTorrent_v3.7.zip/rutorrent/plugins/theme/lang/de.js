﻿/*
 * PLUGIN THEME
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Thema";

thePlugins.get("theme").langLoaded();