﻿/*
 * PLUGIN THEME
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se)
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Tema";

thePlugins.get("theme").langLoaded();