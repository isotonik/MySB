﻿/*
 * PLUGIN SeedingTime
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.seedingTime		= "Ολοκληρώθηκε";
 theUILang.addTime		= "Προστέθηκε";

thePlugins.get("seedingtime").langLoaded();