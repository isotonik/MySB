﻿/*
 * PLUGIN XMPP
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 var s_PluginFail			= "Plugin wird nicht funktionieren.";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID:";
 theUILang.xmppJabberFor 		= "Empfänger:";
 theUILang.xmppMessage			= "Nachricht:";
 theUILang.xmppJabberPasswd		= "Passwort:";
 theUILang.xmppAdvancedSettings		= "Erweitert:";
 theUILang.xmppJabberHost		= "Host:";
 theUILang.xmppJabberPort		= "Port";
 theUILang.xmppUseEncryption		= "Verschlüsselung nutzen";

thePlugins.get("xmpp").langLoaded();
