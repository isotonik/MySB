﻿/*
 * PLUGIN XMPP
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 var s_PluginFail			= "플러그인이 동작하지 않습니다.";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID:";
 theUILang.xmppJabberFor 		= "수신:";
 theUILang.xmppMessage			= "메시지:";
 theUILang.xmppJabberPasswd		= "암호:";
 theUILang.xmppAdvancedSettings		= "고급:";
 theUILang.xmppJabberHost		= "호스트";
 theUILang.xmppJabberPort		= "포트";
 theUILang.xmppUseEncryption		= "암호화 사용";

thePlugins.get("xmpp").langLoaded();
