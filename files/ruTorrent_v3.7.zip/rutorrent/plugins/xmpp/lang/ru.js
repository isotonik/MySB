﻿/*
 * PLUGIN XMPP
 *
 * Russian language file.
 *
 * Author: 
 */

 var s_PluginFail			= "Плагин не будет работать.";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID:";
 theUILang.xmppJabberFor 		= "Кому:";
 theUILang.xmppMessage			= "Сообщение:";
 theUILang.xmppJabberPasswd		= "Пароль:";
 theUILang.xmppAdvancedSettings		= "Расширенные:";
 theUILang.xmppJabberHost		= "Хост:";
 theUILang.xmppJabberPort		= "Порт";
 theUILang.xmppUseEncryption		= "Использовать шифрование";

thePlugins.get("xmpp").langLoaded();
