﻿/*
 * PLUGIN XMPP
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 var s_PluginFail			= "Плагін не працюватиме.";

 theUILang.xmpp 			= "XMPP";
 theUILang.xmppJabberJID 		= "JID:";
 theUILang.xmppJabberFor 		= "Одержувач:";
 theUILang.xmppMessage			= "Повідомлення:";
 theUILang.xmppJabberPasswd		= "Пароль:";
 theUILang.xmppAdvancedSettings		= "Додатково:";
 theUILang.xmppJabberHost		= "Сервер:";
 theUILang.xmppJabberPort		= "Порт";
 theUILang.xmppUseEncryption		= "Використовувати шифрування";

thePlugins.get("xmpp").langLoaded();
