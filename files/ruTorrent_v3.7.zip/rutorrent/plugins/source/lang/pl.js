﻿/*
 * PLUGIN SOURCE
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.getSource		= "Pobierz plik .torrent";
 theUILang.cantFindTorrent	= "Plik .torrent nie znaleziony.";

thePlugins.get("source").langLoaded();