﻿/*
 * PLUGIN THROTTLE
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.throttles		= "Velocidades";
 theUILang.throttle		= "Velocidad";
 theUILang.mnuThrottle		= "Asignar velocidad";
 theUILang.mnuUnlimited 	= "Sin restricción";
 theUILang.channelName		= "Nombre";
 theUILang.channelDefault	= "Velocidad por defecto";

thePlugins.get("throttle").langLoaded();