﻿/*
 * PLUGIN THROTTLE
 *
 * German language file.
 *
 * Author: 
 */

 theUILang.throttles		= "Channels";
 theUILang.throttle		= "Channel";
 theUILang.mnuThrottle		= "Set Channel";
 theUILang.mnuUnlimited 	= "No Channel";
 theUILang.channelName		= "Name";
 theUILang.channelDefault	= "Default channel";

thePlugins.get("throttle").langLoaded();