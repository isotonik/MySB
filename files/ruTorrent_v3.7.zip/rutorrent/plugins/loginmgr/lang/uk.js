﻿/*
 * PLUGIN LoginMGR
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.accLogin		= "Логін";
 theUILang.accPassword		= "Пароль";
 theUILang.accAccounts		= "Облікові записи";
 theUILang.accAuto		= "Автологін";
 theUILang.acAutoNone		= "Ніколи";
 theUILang.acAutoDay		= "Щодня";
 theUILang.acAutoWeek		= "Щотижня";
 theUILang.acAutoMonth		= "Щомісяця";

thePlugins.get("loginmgr").langLoaded();
