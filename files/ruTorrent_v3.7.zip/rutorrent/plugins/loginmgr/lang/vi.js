﻿/*
 * PLUGIN LoginMGR
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.accLogin		= "Tên đăng nhập";
 theUILang.accPassword		= "Mật khẩu";
 theUILang.accAccounts		= "Tài khoản";
 theUILang.accAuto		= "Tự đăng nhập";
 theUILang.acAutoNone		= "Không";
 theUILang.acAutoDay		= "Hàng ngày";
 theUILang.acAutoWeek		= "Hàng tuần";
 theUILang.acAutoMonth		= "Hàng tháng";

thePlugins.get("loginmgr").langLoaded();