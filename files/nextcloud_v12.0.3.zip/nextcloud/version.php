<?php 
$OC_Version = array(12,0,3,3);
$OC_VersionString = '12.0.3';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '11.0' => true,
    '12.0' => true,
  ),
  'owncloud' => 
  array (
    '10.0.0.12' => true,
    '10.0.1.5' => true,
    '10.0.2.1' => true,
  ),
);
$OC_Build = '2017-09-19T21:13:36+00:00 343a69569db0aec48bc99fd3b23da08a7791d82b';
$vendor = 'nextcloud';
