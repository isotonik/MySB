<?php 
$OC_Version = array(12,0,4,3);
$OC_VersionString = '12.0.4';
$OC_Edition = '';
$OC_Channel = 'stable';
$OC_VersionCanBeUpgradedFrom = array (
  'nextcloud' => 
  array (
    '11.0' => true,
    '12.0' => true,
  ),
  'owncloud' => 
  array (
    '10.0.0.12' => true,
    '10.0.1.5' => true,
    '10.0.2.1' => true,
    '10.0.3.3' => true,
    '10.0.4' => true,
  ),
);
$OC_Build = '2017-12-04T07:21:01+00:00 c772810ecabce06f45dea16b7c67185c90df4a0d';
$vendor = 'nextcloud';
