=====================
Introduction
=====================

.. include:: ../README.rst
    :start-after: tag:intro-begin
    :end-before: tag:intro-end
