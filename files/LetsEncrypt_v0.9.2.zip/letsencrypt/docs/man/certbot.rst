.. literalinclude:: ../cli-help.txt
