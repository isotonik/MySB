:mod:`certbot.plugins.common`
---------------------------------

.. automodule:: certbot.plugins.common
   :members:
