﻿/*
 * PLUGIN RETRACKERS
 *
 * Ukrainian language file.
 *
 * Author: Oleksandr Natalenko (oleksandr@natalenko.name)
 */

 theUILang.retrackers		= "Ретрекери";
 theUILang.retrackersAdd	= "Додати анонси";
 theUILang.retrackersDel	= "Видалити анонси";
 theUILang.dontAddToPrivate	= "Не змінювати приватні торенти";
 theUILang.addToBegin		= "Додавати анонси на початок списку трекерів";

thePlugins.get("retrackers").langLoaded();