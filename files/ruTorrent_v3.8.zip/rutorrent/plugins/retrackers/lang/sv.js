﻿/*
 * PLUGIN RETRACKERS
 *
 * Swedish language file.
 *
 * Author: Magnus Holm (holmen@brasse.se) 
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Lägg till meddelanden";
 theUILang.retrackersDel	= "Ta bort meddelanden";
 theUILang.dontAddToPrivate	= "Påverka ej privata torrents";
 theUILang.addToBegin		= "Lägg till meddelanden i början av listan med trackers.";

thePlugins.get("retrackers").langLoaded();
