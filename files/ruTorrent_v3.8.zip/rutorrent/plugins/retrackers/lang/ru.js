﻿/*
 * PLUGIN RETRACKERS
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.retrackers		= "Ретрекеры";
 theUILang.retrackersAdd	= "Добавить анонсеры";
 theUILang.retrackersDel	= "Удалить анонсеры";
 theUILang.dontAddToPrivate	= "Не модифицировать частные раздачи";
 theUILang.addToBegin		= "Добавлять анонсеры в начало списка";

thePlugins.get("retrackers").langLoaded();