﻿/*
 * PLUGIN RETRACKERS
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Announces hinzufügen";
 theUILang.retrackersDel	= "Announces löschen";
 theUILang.dontAddToPrivate	= "Private Torrents ausschließen";
 theUILang.addToBegin		= "Announces zum Anfang der Trackers-Liste hinzufügen";

thePlugins.get("retrackers").langLoaded();