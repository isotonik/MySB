﻿/*
 * PLUGIN RETRACKERS
 *
 * English language file.
 *
 * Author: 
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "Add Announce URLs";
 theUILang.retrackersDel	= "Remove Announce URLs";
 theUILang.dontAddToPrivate	= "Don't touch private torrents";
 theUILang.addToBegin		= "Add announce URLs to the beginning of the trackers list";

thePlugins.get("retrackers").langLoaded();