﻿/*
 * PLUGIN RETRACKERS
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.retrackers		= "Retrackers";
 theUILang.retrackersAdd	= "增加 Announce URLs";
 theUILang.retrackersDel	= "移除 Announce URLs";
 theUILang.dontAddToPrivate	= "不要修改私有的 torrents";
 theUILang.addToBegin		= "将 announce URLs 添加到 trackers 列表的开头";

thePlugins.get("retrackers").langLoaded();
