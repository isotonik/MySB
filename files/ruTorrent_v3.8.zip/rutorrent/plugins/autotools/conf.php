<?php

	// set interval for schedule command in seconds
	$autowatch_interval = 300;

	// set "true" to enable debug output
	$autodebug_enabled = false;
