﻿/*
 * PLUGIN RATIO
 *
 * Czech language file.
 *
 * Author: 
 */

 theUILang.ratios		= "Ratio Groups";
 theUILang.ratio		= "RatioGroup";
 theUILang.mnuRatio		= "Set Ratio Group";
 theUILang.mnuRatioUnlimited	= "No Ratio";
 theUILang.ratioName		= "Name";
 theUILang.minRatio		= "Min";
 theUILang.maxRatio		= "Max";
 theUILang.ratioUpload		= "UL";
 theUILang.ratioAction		= "Action";
 theUILang.ratioStop		= "Stop";
 theUILang.ratioStopAndRemove	= "Stop & Clear group";
 theUILang.ratioErase		= "Remove";
 theUILang.ratioEraseData	= "Remove data";
 theUILang.maxTime		= "Time";
 theUILang.ratioDefault 	= "Default ratio group";
 theUILang.setThrottleTo	= "Set channel to";

thePlugins.get("ratio").langLoaded();