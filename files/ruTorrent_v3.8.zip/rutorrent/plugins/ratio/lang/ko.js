﻿/*
 * PLUGIN RATIO
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.ratios		= "비율 그룹";
 theUILang.ratio		= "비율 그룹";
 theUILang.mnuRatio		= "비율 그룹 설정";
 theUILang.mnuRatioUnlimited	= "비율 미지정";
 theUILang.ratioName		= "이름";
 theUILang.minRatio		= "최소";
 theUILang.maxRatio		= "최대";
 theUILang.ratioUpload		= "UL";
 theUILang.ratioAction		= "행동";
 theUILang.ratioStop		= "정지";
 theUILang.ratioStopAndRemove	= "정지 및 그룹 선택 지우기";
 theUILang.ratioErase		= "제거";
 theUILang.ratioEraseData	= "데이터 제거";
 theUILang.maxTime		= "시간";
 theUILang.ratioDefault 	= "기본 비율 그룹";
 theUILang.setThrottleTo	= "다음 채널로 설정";

thePlugins.get("ratio").langLoaded();
