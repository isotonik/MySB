﻿/*
 * PLUGIN LookAt
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.lookAtDesc = "Finde bei (Format: Name|URL)";
 theUILang.lookAt = "Finde bei";

thePlugins.get("lookat").langLoaded();