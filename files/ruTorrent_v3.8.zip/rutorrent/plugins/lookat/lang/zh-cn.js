﻿/*
 * PLUGIN LookAt
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.lookAtDesc = "在此查找 (格式: 名称|url)";
 theUILang.lookAt = "在此查找";

thePlugins.get("lookat").langLoaded();
