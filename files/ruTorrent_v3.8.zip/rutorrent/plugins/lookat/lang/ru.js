﻿/*
 * PLUGIN LookAt
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.lookAtDesc = "Смотреть на (Формат: name|url)";
 theUILang.lookAt = "Смотреть на";

thePlugins.get("lookat").langLoaded();