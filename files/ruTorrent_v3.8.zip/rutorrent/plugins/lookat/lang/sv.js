﻿/*
 * PLUGIN LookAt
 *
 * Swedish language file.
 *
 * Author: 
 */

 theUILang.lookAtDesc = "Titta på (Format: namn|url)";
 theUILang.lookAt = "Titta på";

thePlugins.get("lookat").langLoaded();
