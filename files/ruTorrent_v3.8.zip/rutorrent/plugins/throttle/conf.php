<?php
// configuration parameters

@define('MAX_THROTTLE', 10, true);
