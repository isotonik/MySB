﻿/*
 * PLUGIN THROTTLE
 *
 * Korean language file.
 *
 * Author: Limerainne (limerainne@gmail.com)
 */

 theUILang.throttles		= "채널";
 theUILang.throttle		= "채널";
 theUILang.mnuThrottle		= "채널 선택";
 theUILang.mnuUnlimited 	= "채널 없음";
 theUILang.channelName		= "이름";
 theUILang.channelDefault	= "기본 채널";

thePlugins.get("throttle").langLoaded();
