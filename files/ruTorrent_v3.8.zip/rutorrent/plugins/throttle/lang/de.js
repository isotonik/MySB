﻿/*
 * PLUGIN THROTTLE
 *
 * German language file.
 *
 * Author: Dario Rugani (kontakt@rugani.de)
 */

 theUILang.throttles		= "Channels";
 theUILang.throttle		= "Channel";
 theUILang.mnuThrottle		= "Channel setzen";
 theUILang.mnuUnlimited 	= "Kein Channel";
 theUILang.channelName		= "Name";
 theUILang.channelDefault	= "Standard Channel";

thePlugins.get("throttle").langLoaded();