﻿/*
 * PLUGIN EXTRATIO
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.ratioRulesManager	= "Administrador de reglas";
 theUILang.mnu_ratiorule	= "Reglas de ratio";
 theUILang.ratAddRule		= "Agregar";
 theUILang.ratDelRule		= "Borrar";
 theUILang.ratUpRule		= "Arriba";
 theUILang.ratDownRule		= "Abajo";
 theUILang.ratioIfLegend	= "Si";
 theUILang.ratLabelContain	= "Etiqueta contiene";
 theUILang.ratTrackerContain	= "Una de las URL de los trackers contiene";
 theUILang.ratTrackerPublic	= "Todos los trackers son públicos";
 theUILang.ratTrackerPrivate	= "Uno de los trackers es privado";
 theUILang.ratioThenLegend	= "Entonces";
 theUILang.setRatioTo		= "setear ratio a";
 theUILang.setChannelTo 	= "Setear acelerador a";
 theUILang.ratioNewRule 	= "Nueva regla";

thePlugins.get("extratio").langLoaded();