# Copyright: 2013 Paul Traylor
# These sources are released under the terms of the MIT license: see LICENSE

__version__ = '1.0.2'
